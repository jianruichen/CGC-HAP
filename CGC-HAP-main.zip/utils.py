import torch
import random
import numpy as np
import networkx as nx
from opt import args
import cdlib
from sklearn import metrics
from munkres import Munkres
from kmeans_gpu import kmeans
import torch.nn.functional as F
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
import itertools


def cluster_acc(y_true, y_pred):
    """
    calculate clustering acc and f1-score
    Args:
        y_true: the ground truth
        y_pred: the clustering id

    Returns: acc and f1-score
    """
    y_true = y_true - np.min(y_true)
    l1 = list(set(y_true))
    num_class1 = len(l1)
    l2 = list(set(y_pred))
    num_class2 = len(l2)
    ind = 0
    if num_class1 != num_class2:
        for i in l1:
            if i in l2:
                pass
            else:
                y_pred[ind] = i
                ind += 1
    l2 = list(set(y_pred))
    numclass2 = len(l2)
    if num_class1 != numclass2:
        print('error')
        return
    cost = np.zeros((num_class1, numclass2), dtype=int)
    for i, c1 in enumerate(l1):
        mps = [i1 for i1, e1 in enumerate(y_true) if e1 == c1]
        for j, c2 in enumerate(l2):
            mps_d = [i1 for i1 in mps if y_pred[i1] == c2]
            cost[i][j] = len(mps_d)
    m = Munkres()
    cost = cost.__neg__().tolist()
    indexes = m.compute(cost)
    new_predict = np.zeros(len(y_pred))
    for i, c in enumerate(l1):
        c2 = l2[indexes[i][1]]
        ai = [ind for ind, elm in enumerate(y_pred) if elm == c2]
        new_predict[ai] = c
    acc = metrics.accuracy_score(y_true, new_predict)
    f1_macro = metrics.f1_score(y_true, new_predict, average='macro')
    return acc, f1_macro


def eva(y_true, y_pred, show_details=True):
    """
    evaluate the clustering performance
    Args:
        y_true: the ground truth
        y_pred: the predicted label
        show_details: if print the details
    Returns: None
    """
    acc, f1 = cluster_acc(y_true, y_pred)
    nmi = nmi_score(y_true, y_pred, average_method='arithmetic')
    ari = ari_score(y_true, y_pred)
    if show_details:
        print(':acc {:.4f}'.format(acc), ', nmi {:.4f}'.format(nmi), ', ari {:.4f}'.format(ari),
              ', f1 {:.4f}'.format(f1))
    return acc, nmi, ari, f1


def load_graph_data(dataset_name, show_details=False):
    """
    load graph data
    :param dataset_name: the name of the dataset
    :param show_details: if show the details of dataset
    - dataset name
    - features' shape
    - labels' shape
    - adj shape
    - edge num
    - category num
    - category distribution
    :return: the features, labels and adj, cluster number
    """
    load_path = "dataset/" + dataset_name + "/" + dataset_name
    feat = np.load(load_path+"_feat.npy", allow_pickle=True)
    label = np.load(load_path+"_label.npy", allow_pickle=True)
    adj = np.load(load_path+"_adj.npy", allow_pickle=True)
    cluster_num = len(np.unique(label))
    node_num = feat.shape[0]
    if show_details:
        print("++++++++++++++++++++++++++++++")
        print("---details of graph dataset---")
        print("++++++++++++++++++++++++++++++")
        print("dataset name:   ", dataset_name)
        print("feature shape:  ", feat.shape)
        print("label shape:    ", label.shape)
        print("adj shape:      ", adj.shape)
        print("undirected edge num:   ", int(np.nonzero(adj)[0].shape[0]/2))
        print("category num:          ", max(label)-min(label)+1)
        print("category distribution: ")
        for i in range(max(label)+1):
            print("label", i, end=":")
            print(len(label[np.where(label == i)]))
        print("++++++++++++++++++++++++++++++")

    if args.n_input != -1:
        pca = PCA(n_components=args.n_input)
        feat = pca.fit_transform(feat)
    return feat, label, torch.tensor(adj).float(), node_num, cluster_num

def load_graph_data1(dataset_name, show_details=False):
    """
    load graph data
    :param dataset_name: the name of the dataset
    :param show_details: if show the details of dataset
    - dataset name
    - features' shape
    - labels' shape
    - adj shape
    - edge num
    - category num
    - category distribution
    :return: the features, labels and adj, cluster number
    """
    load_path = "dataset/" + dataset_name + "/" + dataset_name
    feat = np.load(load_path+"_feat.npy", allow_pickle=True)
    label = np.load(load_path+"_label.npy", allow_pickle=True)
    adj = np.load(load_path+"_adj_ho.npy", allow_pickle=True)
    cluster_num = len(np.unique(label))
    node_num = feat.shape[0]
    if show_details:
        print("++++++++++++++++++++++++++++++")
        print("---details of graph dataset---")
        print("++++++++++++++++++++++++++++++")
        print("dataset name:   ", dataset_name)
        print("feature shape:  ", feat.shape)
        print("label shape:    ", label.shape)
        print("adj shape:      ", adj.shape)
        print("undirected edge num:   ", int(np.nonzero(adj)[0].shape[0]/2))
        print("category num:          ", max(label)-min(label)+1)
        print("category distribution: ")
        for i in range(max(label)+1):
            print("label", i, end=":")
            print(len(label[np.where(label == i)]))
        print("++++++++++++++++++++++++++++++")

    if args.n_input != -1:
        pca = PCA(n_components=args.n_input)
        feat = pca.fit_transform(feat)
    return feat, label, torch.tensor(adj).float(), node_num, cluster_num

def normalize_adj(adj, self_loop=True, symmetry=False):
    """
    normalize the adj matrix
    :param adj: input adj matrix
    :param self_loop: if add the self loop or not
    :param symmetry: symmetry normalize or not
    :return: the normalized adj matrix
    """
    # add the self_loop
    if self_loop:
        adj_tmp = adj + np.eye(adj.shape[0])
    else:
        adj_tmp = adj

    # calculate degree matrix and it's inverse matrix
    d = np.diag(adj_tmp.sum(0))
    d_inv = np.linalg.inv(d)

    # symmetry normalize: D^{-0.5} A D^{-0.5}
    if symmetry:
        sqrt_d_inv = np.sqrt(d_inv)
        norm_adj = np.matmul(np.matmul(sqrt_d_inv, adj_tmp), sqrt_d_inv)

    # non-symmetry normalize: D^{-1} A
    else:
        norm_adj = np.matmul(d_inv, adj_tmp)
    return norm_adj


def setup_seed(seed):
    """
    setup random seed to fix the result
    Args:
        seed: random seed
    Returns: None
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def phi(feature, true_labels, cluster_num):
    predict_labels, centers, dis = kmeans(X=feature, num_clusters=cluster_num, distance="euclidean", device="cuda")
    acc, nmi, ari, f1 = eva(true_labels, predict_labels.numpy(), show_details=False)
    return 100 * acc, 100 * nmi, 100 * ari, 100 * f1, predict_labels.numpy(), centers, dis


def laplacian_filtering(A, X, t):
    A_tmp = A - torch.diag_embed(torch.diag(A))
    A_norm = normalize_adj(A_tmp, self_loop=True, symmetry=True)
    I = torch.eye(A.shape[0])
    L = I - A_norm
    for i in range(t):
        X = (I - L) @ X
    return X.float()


def comprehensive_similarity(Z1, Z2, E1, E2, alpha):
    Z1_Z2 = torch.cat([torch.cat([Z1 @ Z1.T, Z1 @ Z2.T], dim=1),
                       torch.cat([Z2 @ Z1.T, Z2 @ Z2.T], dim=1)], dim=0)

    E1_E2 = torch.cat([torch.cat([E1 @ E1.T, E1 @ E2.T], dim=1),
                       torch.cat([E2 @ E1.T, E2 @ E2.T], dim=1)], dim=0)

    # H1_H2 = torch.cat([torch.cat([H1 @ H1.T, H1 @ H2.T], dim=1),
    #                    torch.cat([H2 @ H1.T, H2 @ H2.T], dim=1)], dim=0)

    S = alpha * Z1_Z2 + (1 - alpha) * E1_E2
    return S

def comprehensive_similarity_1(Z1, Z2, E1, E2, alpha):
    Z1_Z2 = torch.cat([torch.cat([Z1 @ Z1.T, Z1 @ Z2.T], dim=1),
                       torch.cat([Z2 @ Z1.T, Z2 @ Z2.T], dim=1)], dim=0)

    E1_E2 = torch.cat([torch.cat([E1 @ E1.T, E1 @ E2.T], dim=1),
                       torch.cat([E2 @ E1.T, E2 @ E2.T], dim=1)], dim=0)

    # H1_H2 = torch.cat([torch.cat([H1 @ H1.T, H1 @ H2.T], dim=1),
    #                    torch.cat([H2 @ H1.T, H2 @ H2.T], dim=1)], dim=0)

    S = alpha * Z1_Z2 + (1 - alpha) * E1_E2
    return S/S.max()


def hard_sample_aware_infoNCE(S, M, pos_neg_weight, pos_weight, node_num):
    pos_neg = M * torch.exp(S * pos_neg_weight)
    pos = torch.cat([torch.diag(S, node_num), torch.diag(S, -node_num)], dim=0)
    pos = torch.exp(pos * pos_weight)
    neg = (torch.sum(pos_neg, dim=1) - pos)
    infoNEC = (-torch.log(pos / (pos + neg))).sum() / (2 * node_num)
    return infoNEC

def hard_sample_aware_infoNCE_h(S, M, node_num):
    pos_neg = M * torch.exp(S)
    pos = torch.cat([torch.diag(S, node_num), torch.diag(S, -node_num)], dim=0)
    pos = torch.exp(pos)
    neg = (torch.mean(pos_neg, dim=1) - pos)
    infoNEC = (-torch.log(pos / (pos + neg))).sum() / (2 * node_num)
    return infoNEC


def square_euclid_distance(Z, center):
    ZZ = (Z * Z).sum(-1).reshape(-1, 1).repeat(1, center.shape[0])
    CC = (center * center).sum(-1).reshape(1, -1).repeat(Z.shape[0], 1)
    ZZ_CC = ZZ + CC
    ZC = Z @ center.T
    distance = ZZ_CC - 2 * ZC
    return distance


def high_confidence(Z, center):
    distance_norm = torch.min(F.softmax(square_euclid_distance(Z, center), dim=1), dim=1).values
    value, _ = torch.topk(distance_norm, int(Z.shape[0] * (1 - args.tao)))
    index = torch.where(distance_norm <= value[-1],
                                torch.ones_like(distance_norm), torch.zeros_like(distance_norm))

    high_conf_index_v1 = torch.nonzero(index).reshape(-1, )
    high_conf_index_v2 = high_conf_index_v1 + Z.shape[0]
    H = torch.cat([high_conf_index_v1, high_conf_index_v2], dim=0)
    H_mat = np.ix_(H.cpu(), H.cpu())
    return H, H_mat


def pseudo_matrix(P, S, node_num):
    P = torch.tensor(P)
    P = torch.cat([P, P], dim=0)
    Q = (P == P.unsqueeze(1)).float().to(args.device)
    S_norm = (S - S.min()) / (S.max() - S.min())
    M_mat = torch.abs(Q - S_norm) ** args.beta
    M = torch.cat([torch.diag(M_mat, node_num), torch.diag(M_mat, -node_num)], dim=0)
    return M, M_mat


def get_all_triangles(order_3):
    all_triangle_nodes = []
    for triangle in order_3:
        all_triangle_nodes.append(triangle)
    return all_triangle_nodes

def get_all_quadrilaterals(order4):
    all_quadrilaterals = []
    for quadrilateral in order4:
        all_quadrilaterals.append(quadrilateral)
    return all_quadrilaterals

def gaussian_noised_feature(X):
    """
    add gaussian noise to the attribute matrix X
    Args:
        X: the attribute matrix
    Returns: the noised attribute matrix X_tilde
    """
    N_1 = torch.Tensor(np.random.normal(1, 0.1, X.shape))
    N_2 = torch.Tensor(np.random.normal(1, 0.1, X.shape))
    X_tilde1 = X * N_1
    X_tilde2 = X * N_2
    return X_tilde1, X_tilde2

def diffusion_adj(adj, mode="ppr", transport_rate=0.2, steps=3):
    """
    Enhanced graph diffusion for focusing on higher-order connectivity.

    :param adj: input adjacency matrix
    :param mode: the mode of graph diffusion ('ppr' for Personalized PageRank)
    :param transport_rate: the transport rate for diffusion
    :param steps: the number of steps to take (higher steps mean more focus on higher-order connectivity)
    :return: the graph diffusion matrix
    """
    # Add self-loop to the adjacency matrix
    adj_tmp = adj + torch.eye(adj.shape[0], device=adj.device)
    sum_adj_tmp_cpu = adj_tmp.sum(0).cpu().numpy()  # 移动到 CPU 并转换
    d = np.diag(sum_adj_tmp_cpu)  # 现在可以使用 NumPy 函数

    # Calculate the degree matrix and its inverse
    d_inv = np.linalg.inv(d)
    sqrt_d_inv = np.sqrt(d_inv)
    adj_tmp_cpu = adj_tmp.cpu()

    norm_adj = np.matmul(np.matmul(sqrt_d_inv, adj_tmp_cpu), sqrt_d_inv)

    if mode == "ppr":
        # Compute the Personalized PageRank matrix
        # 将numpy数组转换为张量
        eye_tensor = torch.eye(d.shape[0], dtype=norm_adj.dtype, device=norm_adj.device)
        # 使用PyTorch执行操作
        inv_matrix = torch.inverse(eye_tensor - (1 - transport_rate) * norm_adj).to(torch.float32)
        diff_adj = transport_rate * inv_matrix

        # Apply the diffusion steps
        diff_adj = np.linalg.matrix_power(diff_adj, steps)

    return diff_adj

def numpy_to_torch(a, sparse=False):
    """
    numpy array to torch tensor
    :param a: the numpy array
    :param sparse: is sparse tensor or not
    :return: torch tensor
    """
    if sparse:
        a = torch.sparse.Tensor(a)
        a = a.to_sparse()
    else:
        a = torch.FloatTensor(a)
    return a

def remove_edge(A, similarity, remove_rate=0.1):
    """
    remove edge based on embedding similarity
    Args:
        A: the origin adjacency matrix
        similarity: cosine similarity matrix of embedding
        remove_rate: the rate of removing linkage relation
    Returns:
        Am: edge-masked adjacency matrix
    """
    # remove edges based on cosine similarity of embedding
    n_node = A.shape[0]
    for i in range(n_node):
        A[i, torch.argsort(similarity[i].cpu())[:int(round(remove_rate * n_node))]] = 0

    # normalize adj
    Am = normalize_adj(A, self_loop=True, symmetry=False)
    return Am

def perform_pca(tensor, n_components, device):
    pca = PCA(n_components=n_components)
    reduced = pca.fit_transform(tensor.detach().cpu().numpy())
    return torch.from_numpy(reduced).to(device)

def encode_and_fuse(HSAN, HSAN_2, inputs):
    Z1, Z2, E1, E2, _, _ = HSAN(*inputs)
    ZH1, ZH2 = HSAN_2(*inputs)
    E = (E1 + E2) / 2
    Z = (Z1 + Z2) / 2
    ZH = (ZH1 + ZH2) / 2
    return Z1, Z2, ZH1, ZH2, E, Z, ZH

def train_and_evaluate(HSAN, HSAN_2, optimizer, optimizer_2, XH_filtered, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor, y, mask, node_num, cluster_num, y_hat, device, args):
    loss_values = []
    inputs = (XH_filtered, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)

import torch
import random
import numpy as np
from opt import args
from sklearn import metrics
from munkres import Munkres
from kmeans_gpu import kmeans
import torch.nn.functional as F
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from itertools import combinations
import numpy as np
import networkx as nx
import torch
from typing import Sequence
from cdlib import algorithms
from cdlib.utils import convert_graph_formats



def cluster_acc(y_true, y_pred):
    """
    calculate clustering acc and f1-score
    Args:
        y_true: the ground truth
        y_pred: the clustering id

    Returns: acc and f1-score
    """
    y_true = y_true - np.min(y_true)
    l1 = list(set(y_true))
    num_class1 = len(l1)
    l2 = list(set(y_pred))
    num_class2 = len(l2)
    ind = 0
    if num_class1 != num_class2:
        for i in l1:
            if i in l2:
                pass
            else:
                y_pred[ind] = i
                ind += 1
    l2 = list(set(y_pred))
    numclass2 = len(l2)
    if num_class1 != numclass2:
        print('error')
        return
    cost = np.zeros((num_class1, numclass2), dtype=int)
    for i, c1 in enumerate(l1):
        mps = [i1 for i1, e1 in enumerate(y_true) if e1 == c1]
        for j, c2 in enumerate(l2):
            mps_d = [i1 for i1 in mps if y_pred[i1] == c2]
            cost[i][j] = len(mps_d)
    m = Munkres()
    cost = cost.__neg__().tolist()
    indexes = m.compute(cost)
    new_predict = np.zeros(len(y_pred))
    for i, c in enumerate(l1):
        c2 = l2[indexes[i][1]]
        ai = [ind for ind, elm in enumerate(y_pred) if elm == c2]
        new_predict[ai] = c
    acc = metrics.accuracy_score(y_true, new_predict)
    f1_macro = metrics.f1_score(y_true, new_predict, average='macro')
    return acc, f1_macro


def eva(y_true, y_pred, show_details=True):
    """
    evaluate the clustering performance
    Args:
        y_true: the ground truth
        y_pred: the predicted label
        show_details: if print the details
    Returns: None
    """
    acc, f1 = cluster_acc(y_true, y_pred)
    nmi = nmi_score(y_true, y_pred, average_method='arithmetic')
    ari = ari_score(y_true, y_pred)
    if show_details:
        print(':acc {:.4f}'.format(acc), ', nmi {:.4f}'.format(nmi), ', ari {:.4f}'.format(ari),
              ', f1 {:.4f}'.format(f1))
    return acc, nmi, ari, f1

def load_graph_data_h(dataset_name, show_details=False):
    """
    load graph data
    :param dataset_name: the name of the dataset
    :param show_details: if show the details of dataset
    - dataset name
    - features' shape
    - labels' shape
    - adj shape
    - edge num
    - category num
    - category distribution
    :return: the features, labels and adj, cluster number
    """
    load_path = "dataset/" + dataset_name + "/" + dataset_name
    feat = np.load(load_path+"_feat.npy", allow_pickle=True)
    label = np.load(load_path+"_label.npy", allow_pickle=True)
    adj = np.load(load_path+"_adj.npy", allow_pickle=True)
    cluster_num = len(np.unique(label))
    node_num = feat.shape[0]
    if show_details:
        print("++++++++++++++++++++++++++++++")
        print("---details of graph dataset---")
        print("++++++++++++++++++++++++++++++")
        print("dataset name:   ", dataset_name)
        print("feature shape:  ", feat.shape)
        print("label shape:    ", label.shape)
        print("adj shape:      ", adj.shape)
        print("undirected edge num:   ", int(np.nonzero(adj)[0].shape[0]/2))
        print("category num:          ", max(label)-min(label)+1)
        print("category distribution: ")
        for i in range(max(label)+1):
            print("label", i, end=":")
            print(len(label[np.where(label == i)]))
        print("++++++++++++++++++++++++++++++")

    if args.n_input != -1:
        pca = PCA(n_components=args.n_input)
        feat = pca.fit_transform(feat)
    return feat, label, torch.tensor(adj).float(), node_num, cluster_num


def generate_enhanced_matrix(original_matrix, enhanced_matrix):
    n = original_matrix.shape[0]
    for i in range(n):
        for j in range(i + 1, n):
            if original_matrix[i, j] == 0:
                enhanced_matrix[i, j] = 1
                enhanced_matrix[j, i] = 1  # 对于无向图
    return enhanced_matrix

def load_graph_data(dataset_name, show_details=False):
    """
    load graph data
    :param dataset_name: the name of the dataset
    :param show_details: if show the details of dataset
    - dataset name
    - features' shape
    - labels' shape
    - adj shape
    - edge num
    - category num
    - category distribution
    :return: the features, labels and adj, cluster number
    """
    load_path = "dataset/" + dataset_name + "/" + dataset_name
    feat = np.load(load_path+"_feat.npy", allow_pickle=True)
    label = np.load(load_path+"_label.npy", allow_pickle=True)
    adj = np.load(load_path+"_adj_new.npy", allow_pickle=True)
    cluster_num = len(np.unique(label))
    node_num = feat.shape[0]
    if show_details:
        print("++++++++++++++++++++++++++++++")
        print("---details of graph dataset---")
        print("++++++++++++++++++++++++++++++")
        print("dataset name:   ", dataset_name)
        print("feature shape:  ", feat.shape)
        print("label shape:    ", label.shape)
        print("adj shape:      ", adj.shape)
        print("undirected edge num:   ", int(np.nonzero(adj)[0].shape[0]/2))
        print("category num:          ", max(label)-min(label)+1)
        print("category distribution: ")
        for i in range(max(label)+1):
            print("label", i, end=":")
            print(len(label[np.where(label == i)]))
        print("++++++++++++++++++++++++++++++")

    if args.n_input != -1:
        pca = PCA(n_components=args.n_input)
        feat = pca.fit_transform(feat)
    return feat, label, torch.tensor(adj).float(), node_num, cluster_num

def get_all_triangles(order_3):
    all_triangle_nodes = []
    for triangle in order_3:
        all_triangle_nodes.append(triangle)
    return all_triangle_nodes


def find_4_cliques_by_neighborhood_batch(graph, batch_size):
    four_cliques = set()
    nodes = list(graph.nodes())

    for i in range(0, len(nodes), batch_size):
        batch_nodes = nodes[i:i + batch_size]

        for node in batch_nodes:
            neighbors = list(graph.neighbors(node))
            # 在当前节点的邻居中找三节点组合
            for u, v, w in combinations(neighbors, 3):
                # 检查这三节点与当前节点是否形成了一个完全子图（4-Clique）
                if graph.has_edge(u, v) and graph.has_edge(u, w) and graph.has_edge(v, w):
                    four_clique = tuple(sorted([node, u, v, w]))
                    four_cliques.add(four_clique)

    return list(four_cliques)


# 分类四阶全连接为强或弱
def classify_4_cliques(graph, clique_list, labels):
    strong_cliques = []
    weak_cliques = []

    for clique in clique_list:
        # 检查四个节点是否有相同的标签
        if labels[clique[0]] == labels[clique[1]] == labels[clique[2]] == labels[clique[3]]:
            strong_cliques.append(clique)
        else:
            weak_cliques.append(clique)

    return strong_cliques, weak_cliques


def find_4_cycles(graph, batch_size):
    four_cycles = set()
    nodes = list(graph.nodes())

    for i in range(0, len(nodes), batch_size):
        # 处理每个批次的节点
        batch_nodes = nodes[i:i + batch_size]
        for node in batch_nodes:
            neighbors = list(graph.neighbors(node))

            # 查找四阶环
            if len(neighbors) >= 3:  # 至少需要3个邻居才能构成4节点的环
                for u, v, w in combinations(neighbors, 3):
                    # 检查这三个邻居之间是否形成环
                    if graph.has_edge(u, v) and graph.has_edge(v, w) and graph.has_edge(w, u):
                        # 如果节点 node 连接到 u, v, w 且 u, v, w 形成一个三角形，那么就形成了一个四阶环
                        four_cycle = tuple(sorted([node, u, v, w]))
                        four_cycles.add(four_cycle)

    return list(four_cycles)


def find_4_cycles_by_neighborhood_batch(graph, batch_size):
    four_cycles = set()
    nodes = list(graph.nodes())

    for i in range(0, len(nodes), batch_size):
        batch_nodes = nodes[i:i + batch_size]

        for node in batch_nodes:
            neighbors = list(graph.neighbors(node))
            # 在当前节点的邻居中找两节点组合
            for u, v in combinations(neighbors, 2):
                if graph.has_edge(u, v):  # 如果u和v之间有边
                    # 寻找u和v的共同邻居，构成四阶环
                    common_neighbors = set(graph.neighbors(u)).intersection(graph.neighbors(v))
                    if node in common_neighbors:
                        common_neighbors.remove(node)  # 避免重复使用node本身
                    for t in common_neighbors:
                        four_cycle = tuple(sorted([node, u, v, t]))
                        four_cycles.add(four_cycle)

    return list(four_cycles)

def find_triangles_by_node_neighborhood(graph, batch_size):
    triangles = set()
    nodes = list(graph.nodes())

    for i in range(0, len(nodes), batch_size):
        # 处理每个批次的节点
        batch_nodes = nodes[i:i + batch_size]
        for node in batch_nodes:
            neighbors = list(graph.neighbors(node))
            # 找到所有邻居两两组合形成的边对
            for u, v in combinations(neighbors, 2):
                if graph.has_edge(u, v):
                    # 使用集合避免重复的三角形
                    triangle = tuple(sorted([node, u, v]))
                    triangles.add(triangle)

    return list(triangles)


# 获取所有四阶环
def get_all_4_cycles(four_cycles):
    all_4_cycle_nodes = []
    for cycle in four_cycles:
        all_4_cycle_nodes.append(cycle)
    return all_4_cycle_nodes


# 分类四阶环为强或弱
def classify_4_cycles(graph, cycle_list, labels):
    strong_cycles = []
    weak_cycles = []

    for cycle in cycle_list:
        # 检查四个节点是否有相同的标签
        if labels[cycle[0]] == labels[cycle[1]] == labels[cycle[2]] == labels[cycle[3]]:
            strong_cycles.append(cycle)
        else:
            weak_cycles.append(cycle)

    return strong_cycles, weak_cycles

def get_all_4_cliques(four_cliques):
    all_4_clique_nodes = []
    for clique in four_cliques:
        all_4_clique_nodes.append(clique)
    return all_4_clique_nodes



def normalize_adj(adj, self_loop=True, symmetry=False):
    """
    normalize the adj matrix
    :param adj: input adj matrix
    :param self_loop: if add the self loop or not
    :param symmetry: symmetry normalize or not
    :return: the normalized adj matrix
    """
    # add the self_loop
    if self_loop:
        adj_tmp = adj + np.eye(adj.shape[0])
    else:
        adj_tmp = adj

    # calculate degree matrix and it's inverse matrix
    d = np.diag(adj_tmp.sum(0))
    d_inv = np.linalg.inv(d)

    # symmetry normalize: D^{-0.5} A D^{-0.5}
    if symmetry:
        sqrt_d_inv = np.sqrt(d_inv)
        norm_adj = np.matmul(np.matmul(sqrt_d_inv, adj_tmp), sqrt_d_inv)

    # non-symmetry normalize: D^{-1} A
    else:
        norm_adj = np.matmul(d_inv, adj_tmp)
    return norm_adj


def setup_seed(seed):
    """
    setup random seed to fix the result
    Args:
        seed: random seed
    Returns: None
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

def phi1(feature, true_labels, cluster_num):
    predict_labels, centers, dis = kmeans(X=feature, num_clusters=cluster_num, distance="euclidean", device="cuda")
    acc, nmi, ari, f1 = eva(true_labels, predict_labels.numpy(), show_details=False)
    return 100 * acc, 100 * nmi, 100 * ari, 100 * f1, predict_labels.numpy(), centers, dis


def phi2(feature, true_labels, cluster_num):
    predict_labels, centers, dis = kmeans(X=feature, num_clusters=cluster_num, distance="euclidean", device="cuda")
    acc, nmi, ari, f1 = eva(true_labels, predict_labels.numpy(), show_details=False)
    return 100 * acc, 100 * nmi, 100 * ari, 100 * f1, predict_labels.numpy(), centers


def laplacian_filtering(A, X, t):
    A_tmp = A - torch.diag_embed(torch.diag(A))
    A_norm = normalize_adj(A_tmp, self_loop=True, symmetry=True)
    I = torch.eye(A.shape[0])
    L = I - A_norm
    for i in range(t):
        X = (I - L) @ X
    return X.float()


def comprehensive_similarity(Z1, Z2, E1, E2, alpha):
    Z1_Z2 = torch.cat([torch.cat([Z1 @ Z1.T, Z1 @ Z2.T], dim=1),
                       torch.cat([Z2 @ Z1.T, Z2 @ Z2.T], dim=1)], dim=0)

    E1_E2 = torch.cat([torch.cat([E1 @ E1.T, E1 @ E2.T], dim=1),
                       torch.cat([E2 @ E1.T, E2 @ E2.T], dim=1)], dim=0)

    S = alpha * Z1_Z2 + (1 - alpha) * E1_E2
    return S


def hard_sample_aware_infoNCE(S, M, pos_neg_weight, pos_weight, node_num):
    pos_neg = M * torch.exp(S * pos_neg_weight)
    pos = torch.cat([torch.diag(S, node_num), torch.diag(S, -node_num)], dim=0)
    pos = torch.exp(pos * pos_weight)
    neg = (torch.sum(pos_neg, dim=1) - pos)
    infoNEC = (-torch.log(pos / (pos + neg))).sum() / (2 * node_num)
    return infoNEC


def square_euclid_distance(Z, center):
    ZZ = (Z * Z).sum(-1).reshape(-1, 1).repeat(1, center.shape[0])
    CC = (center * center).sum(-1).reshape(1, -1).repeat(Z.shape[0], 1)
    ZZ_CC = ZZ + CC
    ZC = Z @ center.T
    distance = ZZ_CC - 2 * ZC
    return distance


def high_confidence(Z, center):
    distance_norm = torch.min(F.softmax(square_euclid_distance(Z, center), dim=1), dim=1).values
    value, _ = torch.topk(distance_norm, int(Z.shape[0] * (1 - args.tao)))
    index = torch.where(distance_norm <= value[-1],
                                torch.ones_like(distance_norm), torch.zeros_like(distance_norm))

    high_conf_index_v1 = torch.nonzero(index).reshape(-1, )
    high_conf_index_v2 = high_conf_index_v1 + Z.shape[0]
    H = torch.cat([high_conf_index_v1, high_conf_index_v2], dim=0)
    H_mat = np.ix_(H.cpu(), H.cpu())
    return H, H_mat


def pseudo_matrix(P, S, node_num):
    P = torch.tensor(P)
    P = torch.cat([P, P], dim=0)
    Q = (P == P.unsqueeze(1)).float().to(args.device)
    S_norm = (S - S.min()) / (S.max() - S.min())
    M_mat = torch.abs(Q - S_norm) ** args.beta
    M = torch.cat([torch.diag(M_mat, node_num), torch.diag(M_mat, -node_num)], dim=0)
    return M, M_mat

def find_negative_sample_for_triangle(triangle, A, existing_neg_samples):
    """
    对于给定的三角形，找到一个与之相关的负样本。
    """
    # 随机选择一个边
    edge = random.choice(list(combinations(triangle, 2)))
    edge_nodes = set(edge)

    # 找到一个不与边上任何一个节点相连的节点
    all_nodes = set(range(A.shape[0]))
    possible_nodes = list(all_nodes - edge_nodes)

    # 打乱可能的节点顺序
    random.shuffle(possible_nodes)

    for node in possible_nodes:
        if A[node, edge[0]] == 0 and A[node, edge[1]] == 0:
            # 创建一个新的"三角形"
            neg_triangle = tuple(sorted([node, edge[0], edge[1]]))
            if neg_triangle not in existing_neg_samples:
                return neg_triangle

    return None


def concatenate_features_for_sample(node_list, X):
    """
    对于给定的节点组，例如一个三角形，从特征矩阵X中提取并拼接这些节点的特征。

    参数:
    - node_list: 节点ID的列表或元组，例如一个三角形的三个节点。
    - X: 所有节点的特征矩阵，每一行对应于一个节点的特征

    返回:
    - 拼接后的特征向量
    """
    # 检查输入
    if not isinstance(node_list, (list, tuple)):
        raise ValueError("node_list should be a list or tuple of node IDs")

    if not isinstance(X, np.ndarray):
        raise ValueError("X should be a numpy array")

    # 从X中提取节点特征并拼接
    concatenated_features = np.concatenate([X[node] for node in node_list], axis=0)

    return concatenated_features


def weighted_average_features_for_sample(node_list, X):
    """
    对于给定的节点列表，例如一个三角形，从特征矩阵X中提取这些节点的特征，并计算它们的加权平均。

    参数:
    - node_list: 节点ID的列表或元组，例如一个三角形的三个节点。
    - X: 所有节点的特征矩阵，每一行对应于一个节点的特征。

    返回:
    - 加权平均后的特征向量。
    """
    # 检查输入
    if not isinstance(node_list, (list, tuple)):
        raise ValueError("node_list should be a list or tuple of node IDs")

    if not isinstance(X, np.ndarray):
        raise ValueError("X should be a numpy array")

    # 从X中提取节点特征并计算加权平均
    node_features = [X[node] for node in node_list]
    weighted_average = np.mean(node_features, axis=0)

    return weighted_average
def classify_triangles(graph, triangle_list, labels):
    strong_triangles = []
    weak_triangles = []

    for tri in triangle_list:
        # 检查三个节点是否有相同的标签
        if labels[tri[0]] == labels[tri[1]] == labels[tri[2]]:
            strong_triangles.append(tri)
        else:
            weak_triangles.append(tri)

    return strong_triangles, weak_triangles


def add_triangle_to_adj_matrix(triangle, A):
    """
    在给定的邻接矩阵A中添加一个三角形的边。
    仅在A的值为0的地方添加边。
    triangle: 三个节点组成的列表或元组。
    A: 原始的邻接矩阵。
    """
    for i in range(3):
        for j in range(i + 1, 3):
            if A[triangle[i], triangle[j]] == 0:
                A[triangle[i], triangle[j]] = 1
                A[triangle[j], triangle[i]] = 1
    return A


def find_common_neighbors(A_sparse, i, j):
    """为两个节点找到共同的邻居"""
    neighbors_i = set(A_sparse.indices[A_sparse.indptr[i]:A_sparse.indptr[i + 1]])
    neighbors_j = set(A_sparse.indices[A_sparse.indptr[j]:A_sparse.indptr[j + 1]])
    return neighbors_i.intersection(neighbors_j)

def community_detection(name):
    algs = {
        # non-overlapping algorithms
        'louvain': algorithms.louvain,
        'combo': algorithms.pycombo,
        'leiden': algorithms.leiden,
        'ilouvain': algorithms.ilouvain,
        'eigenvector': algorithms.eigenvector,
        'girvan_newman': algorithms.girvan_newman,
        # overlapping algorithms
        'demon': algorithms.demon,
        'lemon': algorithms.lemon,
        'ego-splitting': algorithms.egonet_splitter,
        'nnsed': algorithms.nnsed,
        'lpanni': algorithms.lpanni,
    }
    return algs[name]

def transition(communities: Sequence[Sequence[int]],
               num_nodes: int) -> np.ndarray:
    classes = np.full(num_nodes, -1)
    for i, node_list in enumerate(communities):
        classes[np.asarray(node_list)] = i
    return classes

def filter_triangles(node_communities, predicted_positive_triangles):
    same_community_triangles = []

    for triangle in predicted_positive_triangles:
        # 解包三角形的三个节点
        node1, node2, node3 = triangle

        # 检查这三个节点是否属于同一社区
        if node_communities[node1] == node_communities[node2] == node_communities[node3]:
            same_community_triangles.append(triangle)

    return same_community_triangles


# Function to count 4-cycles using adjacency matrix
def count_4_cycles(graph):
    """
    Count the number of 4-cycles in the graph using adjacency matrix operations.
    This method avoids explicit enumeration to improve efficiency.
    """
    # Convert the graph to an adjacency matrix (sparse format)
    A = nx.adjacency_matrix(graph).tocsc()

    # Calculate A^2 (squared adjacency matrix)
    A2 = A @ A

    # Calculate A^3 (cubed adjacency matrix)
    # This is used to detect triangles in the graph as well
    A3 = A2 @ A

    # Total 4-cycles can be derived from the adjacency matrix multiplication
    # Formula: Trace(A^2 - A) // 8 (correctly computes closed 4-cycles from adjacency structures)
    cycle_count = (A2.multiply(A).sum() - A.sum()) // 8  # Divide by 8 to avoid over-counting

    return int(cycle_count)

    # Function to count 4-cliques


def count_4_cliques(graph):
    cliques = list(nx.enumerate_all_cliques(graph))
    # Filter cliques of size 4
    cliques_4 = [clique for clique in cliques if len(clique) == 4]
    return len(cliques_4)


def validate_suffix(suffix):
    support_suffix = [".png", ".pdf", ".jpg", "jpeg", ".bmp", ".tiff", ".gif", ".svg", ".eps"]
    if suffix not in support_suffix:
        return False
    return True