# Contrastive Deep Graph Clustering via Higher-order Heuristic Augmentation and Propagation (CGC-HAP)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

This repository contains the official implementation of **CGC-HAP**, a novel contrastive deep graph clustering method that leverages higher-order heuristic augmentation and propagation to significantly improve clustering performance on graph-structured data. The method addresses key challenges in deep graph clustering, including graph sparsity, semantic drift, and limited discriminative power.

## Key Features

- 🧠 **Higher-order Heuristic Augmentation**: Discovers and enhances reliable intra-cluster higher-order patterns
- 🌐 **Higher-order Propagation**: Captures complex structural relationships beyond pairwise connections
- ⚖ **Hard Sample Aware Contrastive Learning**: Dynamically weights sample pairs to focus on challenging samples
- 🔄 **Unified Framework**: Jointly optimizes representation learning and clustering objectives
- 📈 **State-of-the-art Performance**: Outperforms existing methods across multiple benchmark datasets

## Method Overview

CGC-HAP integrates three key components:

1. **Higher-order Heuristic Augmentation**:
   - Identifies potential higher-order patterns (triangles, 4-cycles, etc.)
   - Filters reliable patterns using community pseudo-labels and attribute similarity
   - Enhances the graph structure by adding reliable connections

2. **Multi-perspective Encoding**:
   - Global attribute encoder (MLP) captures overall node attributes
   - Local structure encoder (GAT) models neighborhood relationships
   - Higher-order propagation (HGNN) captures complex structural patterns

3. **Joint Optimization**:
   - Hard sample aware contrastive loss focuses on challenging samples
   - Center loss encourages tight clustering around centroids
   - Adaptive feature fusion combines global, local, and higher-order features

![CGC-HAP Framework](framework.png)

## Requirements

The code requires the following Python packages:

```
torch>=1.10.0
scipy>=1.7.0
numpy>=1.21.0
scikit-learn>=1.0.0
networkx>=2.6.0
tqdm>=4.62.0
torch-geometric>=2.0.0
cdlib>=0.2.1
```

## Installation

1. Clone the repository:
```bash
git clone https://github.com/jianruichen/CGC-HAP.git
cd CGC-HAP
```

2. Create and activate a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # Linux/MacOS
venv\Scripts\activate    # Windows
```

3. Install the dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Training CGC-HAP

Run the main training script with default parameters:
```bash
python main.py --dataset cora
```

### Command Line Arguments

| Argument | Default | Description |
|----------|---------|-------------|
| `--dataset` | `cora` | Dataset name (`cora`, `citeseer`, `amap`, `acm`, `wiki`) |
| `--dims` | `500` | Hidden dimensions (1500 for larger datasets) |
| `--lr` | `0.001` | Learning rate |
| `--epochs` | `500` | Number of training epochs |
| `--lambda` | `2.0` | Center loss weight |
| `--xi` | `0.9` | High-confidence sample ratio |
| `--tau` | `0.9` | Similarity threshold for augmentation |
| `--runs` | `10` | Number of runs with different random seeds |
| `--device` | `cuda` | Computation device (`cuda` or `cpu`) |

## Datasets

CGC-HAP has been evaluated on five benchmark datasets:

| Dataset | Nodes | Edges | Features | Classes | Type |
|---------|-------|-------|----------|---------|------|
| CORA | 2,708 | 5,278 | 1,433 | 7 | Citation Network |
| CITESEER | 3,327 | 4,552 | 3,703 | 6 | Citation Network |
| AMAP | 7,650 | 119,081 | 745 | 8 | Amazon Co-purchase |
| ACM | 3,025 | 13,128 | 1,870 | 3 | Paper Network |
| WIKI | 2,405 | 8,261 | 4,973 | 17 | Wikipedia Co-occurrence |

## Results

CGC-HAP achieves state-of-the-art performance across multiple datasets:

### Clustering Performance on CORA

| Method | ACC | NMI | ARI | F1 |
|--------|-----|-----|-----|----|
| DAEGC | 70.43 | 52.89 | 49.63 | 68.27 |
| SDCN | 35.60 | 14.28 | 07.78 | 24.37 |
| DCRN | 61.93 | 45.13 | 33.15 | 49.50 |
| CCGC | 73.88 | 56.45 | 52.51 | 70.98 |
| HSAN | 77.07 | 59.21 | 57.52 | 75.11 |
| **CGC-HAP** | **78.71** | **61.73** | **60.13** | **77.07** |

### Performance Comparison Across Datasets

![Performance Comparison](results.png)

## Citation

If you use CGC-HAP in your research, please cite our paper:

```bibtex
@article{zheng2024contrastive,
  title={Contrastive Deep Graph Clustering via Higher-order Heuristic Augmentation and Propagation},
  author={Zheng, Zheyu and Chen, Jianrui and Huang, Junjie and Wang, Junbo},
  journal={Engineering Applications of Artificial Intelligence},
  year={2024}
}
```