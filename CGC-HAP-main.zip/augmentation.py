import numpy as np
import torch
import torch.nn as nn
from torch import optim
from scipy.sparse import coo_matrix, csr_matrix
import networkx as nx
from itertools import combinations
import random
from utils import setup_seed, load_graph_data_h, laplacian_filtering
from model import AttentionMLP
from utils import phi2  # Assuming phi2 is defined in functional.py
from setup import setup_args


# Function definitions
def weighted_average_features_for_sample(nodes, features):
    """Compute weighted average features for given nodes"""
    node_features = features[list(nodes)]
    if isinstance(node_features, torch.Tensor):
        return node_features.mean(dim=0).numpy()
    else:  # numpy array
        return node_features.mean(axis=0)


def classify_triangles(triangles, labels):
    """Classify triangles into strong (same community) and weak (mixed communities)"""
    if isinstance(labels, torch.Tensor):
        labels = labels.numpy()

    strong, weak = [], []
    for triangle in triangles:
        comm = labels[triangle[0]]
        if all(labels[node] == comm for node in triangle):
            strong.append(triangle)
        else:
            weak.append(triangle)
    return strong, weak


def find_negative_sample_for_triangle(triangle, adj_matrix, existing_set):
    """Generate negative sample by replacing one node while keeping two connected"""
    nodes = list(triangle)
    random.shuffle(nodes)
    n = adj_matrix.shape[0]

    for i in range(3):
        # Try replacing each vertex
        candidates = set(range(n)) - set(triangle)
        for candidate in candidates:
            # Create new triangle candidate
            new_tri = list(nodes)
            new_tri[i] = candidate
            new_tri = tuple(sorted(new_tri))

            # Skip if already exists
            if new_tri in existing_set:
                continue

            # Check connections (should have 2 edges, missing 1)
            edge_count = 0
            if isinstance(adj_matrix, torch.Tensor):
                edge_count += adj_matrix[new_tri[0], new_tri[1]].item()
                edge_count += adj_matrix[new_tri[1], new_tri[2]].item()
                edge_count += adj_matrix[new_tri[0], new_tri[2]].item()
            else:  # numpy array
                edge_count += adj_matrix[new_tri[0], new_tri[1]]
                edge_count += adj_matrix[new_tri[1], new_tri[2]]
                edge_count += adj_matrix[new_tri[0], new_tri[2]]

            # Valid negative sample should have exactly 2 edges
            if edge_count == 2:
                return new_tri
    return None


def add_triangle_edges(triangle, adj_matrix):
    """Add missing edges in triangle to adjacency matrix"""
    for i, j in combinations(triangle, 2):
        if adj_matrix[i, j] == 0:
            adj_matrix[i, j] = 1
            adj_matrix[j, i] = 1
    return adj_matrix


def find_common_neighbors(adj_sparse, i, j):
    """Find common neighbors between two nodes"""
    neighbors_i = set(adj_sparse.indices[adj_sparse.indptr[i]:adj_sparse.indptr[i + 1]])
    neighbors_j = set(adj_sparse.indices[adj_sparse.indptr[j]:adj_sparse.indptr[j + 1]])
    return neighbors_i.intersection(neighbors_j)


if __name__ == '__main__':
    DATASET = "cora"
    args = setup_args(DATASET)

    # Initialize best score tracking
    best_score = -np.inf
    best_A_new = None

    for seed in range(args.runs):
        setup_seed(seed)

        # Load and prepare graph data
        features, labels, adj_matrix, num_nodes, num_clusters = load_graph_data_h(DATASET)
        graph = nx.Graph()
        graph.add_nodes_from(range(num_nodes))
        sparse_adj = coo_matrix(adj_matrix.numpy())
        graph.add_edges_from(zip(sparse_adj.row, sparse_adj.col))

        # Extract and classify triangles
        triangles = [tuple(sorted(tri)) for tri in nx.enumerate_all_cliques(graph) if len(tri) == 3]
        strong_tris, weak_tris = classify_triangles(triangles, labels)

        # Prepare training data
        pos_samples = triangles[:len(triangles)]  # Use all triangles as positives
        neg_samples = []
        existing_negs = set()

        for tri in pos_samples:
            neg_tri = find_negative_sample_for_triangle(tri, adj_matrix, existing_negs)
            if neg_tri:
                neg_samples.append(neg_tri)
                existing_negs.add(neg_tri)

        # Compute features and labels
        pos_features = [weighted_average_features_for_sample(tri, features) for tri in pos_samples]
        neg_features = [weighted_average_features_for_sample(tri, features) for tri in neg_samples]
        X_train = torch.tensor(pos_features + neg_features, dtype=torch.float32)
        y_train = torch.tensor([1] * len(pos_features) + [0] * len(neg_features),
                               dtype=torch.float32).view(-1, 1)

        # Initialize and train model
        model = AttentionMLP(X_train.shape[1], 128, [512, 256, 128])
        optimizer = optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-4)
        criterion = nn.BCEWithLogitsLoss()

        for epoch in range(1000):
            model.train()
            optimizer.zero_grad()
            outputs = model(X_train)
            loss = criterion(outputs, y_train)
            loss.backward()
            optimizer.step()

        # Generate candidate triangles (non-edges with common neighbor)
        sparse_adj = csr_matrix(adj_matrix.numpy())
        candidate_tris = set()

        for i in range(num_nodes):
            for j in range(i + 1, num_nodes):
                if sparse_adj[i, j] == 0:
                    common_neighbors = find_common_neighbors(sparse_adj, i, j)
                    if common_neighbors:
                        neighbor = next(iter(common_neighbors))
                        candidate_tris.add(tuple(sorted((i, j, neighbor))))

        # Predict and filter triangles
        with torch.no_grad():
            model.eval()
            if candidate_tris:
                tri_features = [weighted_average_features_for_sample(tri, features) for tri in candidate_tris]
                tri_tensor = torch.tensor(tri_features, dtype=torch.float32)
                probs = torch.sigmoid(model(tri_tensor)).numpy()
                THRESHOLD = 0.9999
                predicted_tris = [tri for tri, prob in zip(candidate_tris, probs) if prob >= THRESHOLD]
            else:
                predicted_tris = []

        # Enhance adjacency matrix
        new_adj = adj_matrix.numpy().copy()
        for tri in predicted_tris:
            new_adj = add_triangle_edges(tri, new_adj)

        # Apply Laplacian filtering to the new adjacency matrix
        new_adj_tensor = torch.tensor(new_adj, dtype=torch.float32)
        XH_filtered_new = laplacian_filtering(new_adj_tensor, features, args.t)

        # Evaluate clustering performance - handle variable return count
        metrics = phi2(XH_filtered_new, labels, num_clusters)

        # Extract F1 score based on return count
        if len(metrics) >= 4:
            # F1 is the 4th element in both 6 and 7 return versions
            f1_xn = metrics[3]
        else:
            print(f"Unexpected return count from phi2: {len(metrics)}")
            f1_xn = 0.0  # Default value if can't extract

        print(
            f"Run {seed}: F1 score = {f1_xn:.4f}, Edges added: {np.count_nonzero(new_adj) - np.count_nonzero(adj_matrix.numpy())}")

        # Track best performing adjacency matrix
        if f1_xn > best_score:
            best_score = f1_xn
            best_A_new = new_adj.copy()
            print(f"New best score: {best_score:.4f}")

    # Save best performing adjacency matrix
    if best_A_new is not None:
        np.save('dataset/cora/cora_adj_new.npy', best_A_new)
        print(f"Saved best adjacency matrix with score {best_score:.4f}")