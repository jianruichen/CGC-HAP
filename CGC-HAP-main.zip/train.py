from scipy.sparse import coo_matrix
from utils import *
from tqdm import tqdm
from setup import setup_args
from model import encoding_network, hypergraph_network, CenterLoss
from sklearn.decomposition import PCA
import torch
import torch.optim as optim

if __name__ == '__main__':
    epoch_values = []  # 存储每个 epoch 的值
    loss_values = []  # 存储每个 epoch 对应的损失值

    # for dataset_name in ["cora", "citeseer", "amap", "bat", "eat", "uat"]:
    for dataset_name in ["cora"]:

        # setup hyper-parameter
        args = setup_args(dataset_name)

        # record results
        file = open("result.csv", "a+")
        print(args.dataset, file=file)
        print("ACC,   NMI,   ARI,   F1", file=file)
        file.close()
        acc_list = []
        nmi_list = []
        ari_list = []
        f1_list = []

        # ten runs with different random seeds
        for args.seed in range(args.runs):
            # record results

            # fix the random seed
            setup_seed(args.seed)

            # load graph data
            X, y, A, node_num, cluster_num = load_graph_data(dataset_name, show_details=False)
            _, _, A_HO, _, _ = load_graph_data1(dataset_name, show_details=False)

            graph = nx.Graph()
            graph_H = nx.Graph()

            num_nodes = A.shape[0]
            H_num_nodes = A_HO.shape[0]
            graph.add_nodes_from(range(num_nodes))
            graph_H.add_nodes_from(range(H_num_nodes))

            A_coo = coo_matrix(A.numpy())
            AH_coo = coo_matrix(A_HO.numpy())
            rows, cols = AH_coo.row, AH_coo.col
            data = AH_coo.data

            edges = zip(A_coo.row, A_coo.col)
            high_edges = zip(AH_coo.row, AH_coo.col)
            graph.add_edges_from(edges)
            graph_H.add_edges_from(high_edges)
            cliques_h = list(nx.enumerate_all_cliques(graph_H))
            high_order_3 = [tri for tri in cliques_h if len(tri) == 3]

            for node, attrs in enumerate(X):
                attr_dict = {f'attr_{i}': attr for i, attr in enumerate(attrs)}
                nx.set_node_attributes(graph, attr_dict, node)

            edges = list(graph.edges())
            edge_index = [(edges[i][0], edges[i][1]) for i in range(len(edges))]
            edge_index = torch.tensor(edge_index, dtype=torch.long).t()

            nodes = [i for i in range(A.shape[0])]

            node_index_map = {node: index for index, node in enumerate(nodes)}

            A_raw = A.clone()

            n_nodes = num_nodes
            n_hyperedges = len(high_order_3)

            H = np.zeros((n_nodes, n_hyperedges), dtype=np.float32)
            edge_num = H.shape[1]
            for i, nodes in enumerate(high_order_3):
                H[nodes, i] = 1
            H_tensor = torch.tensor(H, dtype=torch.float32)

            D_v_tensor = torch.sum(H_tensor, dim=1)
            D_e_tensor = torch.sum(H_tensor, dim=0)

            D_v_inv_sqrt = torch.diag(1.0 / torch.clamp(torch.sqrt(D_v_tensor), min=1e-5))
            D_e_inv_sqrt = torch.diag(1.0 / torch.clamp(torch.sqrt(D_e_tensor), min=1e-5))

            H_tensor = H_tensor.to(args.device)
            D_v_inv_sqrt_tensor = D_v_inv_sqrt.to(args.device)
            D_e_inv_sqrt_tensor = D_e_inv_sqrt.to(args.device)

            XH_filtered = laplacian_filtering(A, X, args.t)


            # test
            args.acc, args.nmi, args.ari, args.f1, y_hat, center, dis = phi(XH_filtered, y, cluster_num)

            # build our hard sample aware network
            encoder = encoding_network(
                input_dim=XH_filtered.shape[1], hidden_dim=args.dims, act=args.activate, n_num=node_num, e_num=edge_num, num_heads = 2)

            optimizer = optim.Adam(encoder.parameters(), lr=args.lr)

            HGNN = hypergraph_network(
                input_dim=XH_filtered.shape[1], hidden_dim=args.dims, act=args.activate, n_num=node_num, e_num=edge_num, num_heads = 2)
            num_classes = cluster_num
            feat_dim = args.dims
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

            center_loss = CenterLoss(num_classes, feat_dim, device)
            optimizer_2  = torch.optim.Adam(list(HGNN.parameters()) + list(center_loss.parameters()), lr=0.001)
            # positive and negative sample pair index matrix
            mask = torch.ones([node_num * 2, node_num * 2]) - torch.eye(node_num * 2)

            # load data to device
            A, encoder, HGNN, center_loss, XH_filtered, mask = map(lambda x: x.to(args.device), (A, encoder, HGNN, center_loss, XH_filtered, mask))
            target = torch.eye(XH_filtered.shape[0]).to(args.device)


            for epoch in tqdm(range(args.epochs), desc="training..."):
                # train mode
                encoder.train()
                HGNN.train()

                Z1, Z2, E1, E2, _, _ = encoder(XH_filtered, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)
                ZH1, ZH2 = HGNN(XH_filtered, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)
                # fusion and testing
                E = 0.3 * E1 + 0.7 * E2
                Z = 0.7 * Z1 + 0.3 * Z2
                ZH = (ZH1 + ZH2) / 2

                pca1 = PCA(n_components=1500)

                E_reduced = pca1.fit_transform(E.detach().cpu().numpy())

                E_reduced = torch.from_numpy(E_reduced).to(Z.device)

                Zz = E_reduced + ZH

                Zf = torch.cat((Zz, Z), dim=1)
                pca2 = PCA(n_components=400)
                Zf_reduced = pca2.fit_transform(Zf.detach().cpu().numpy())
                Zf_reduced = torch.from_numpy(Zf_reduced).to(Z.device)

                _, _, _, _, P, _, _ = phi(Zf_reduced, y, cluster_num)
                Z_c1 = ZH1 + Z1
                Z_c2 = ZH2 + Z2
                S = comprehensive_similarity(Z1, Z2, E1, E2, encoder.alpha1)
                S_h = comprehensive_similarity_1(ZH1, ZH2, E1, E2, encoder.alpha2)
                y_hat_tensor = torch.tensor(P, dtype=torch.long, device=device)

                loss1 = hard_sample_aware_infoNCE(S, mask, encoder.pos_neg_weight, encoder.pos_weight, node_num)
                loss2 =2 * center_loss(Z_c1, y_hat_tensor)
                loss = loss1 + loss2

                # optimization
                loss.backward()
                loss_values.append(loss.item())
                optimizer.step()
                optimizer_2.step()

                # testing and update weights of sample pairs
                if epoch % 10 == 0:
                    # evaluation mode
                    encoder.eval()
                    HGNN.eval()

                    # encoding
                    Z1, Z2, E1, E2, _, _ = encoder(XH_filtered, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)
                    ZH1, ZH2 = HGNN(XH_filtered, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)
                    S = comprehensive_similarity(Z1, Z2, E1, E2, encoder.alpha1)
                    E = 0.3 * E1 + 0.7 * E2
                    Z = 0.7 * Z1 + 0.3 * Z2
                    ZH = (ZH1 + ZH2) / 2

                    pca1 = PCA(n_components=1500)
                    E_reduced = pca1.fit_transform(E.detach().cpu().numpy())
                    E_reduced = torch.from_numpy(E_reduced).to(Z.device)
                    Zz = E_reduced + ZH
                    Zf = torch.cat((Zz, Z), dim=1)
                    pca2 = PCA(n_components=450)
                    Zf_reduced = pca2.fit_transform(Zf.detach().cpu().numpy())
                    Zf_reduced = torch.from_numpy(Zf_reduced).to(Z.device)
                    acc, nmi, ari, f1, P, center, dis = phi(Zf_reduced, y, cluster_num)

                    # select high confidence samples
                    H, H_mat = high_confidence(Zf_reduced, center)

                    # calculate new weight of sample pair by Eq. (9)
                    M, M_mat = pseudo_matrix(P, S, node_num)

                    # update weight
                    encoder.pos_weight[H] = M[H].data
                    encoder.pos_neg_weight[H_mat] = M_mat[H_mat].data

                    # recording
                    if acc >= args.acc:
                        args.acc, args.nmi, args.ari, args.f1 = acc, nmi, ari, f1

            print("Training complete")
            epoch_values = [i for i in range(args.epochs)]

            # record results
            file = open("result.csv", "a+")
            print("{:.2f}, {:.2f}, {:.2f}, {:.2f}".format(args.acc, args.nmi, args.ari, args.f1), file=file)
            file.close()
            acc_list.append(args.acc)
            nmi_list.append(args.nmi)
            ari_list.append(args.ari)
            f1_list.append(args.f1)

        # record results
        acc_list, nmi_list, ari_list, f1_list = map(lambda x: np.array(x), (acc_list, nmi_list, ari_list, f1_list))
        file = open("result.csv", "a+")
        print("{:.2f}, {:.2f}".format(acc_list.mean(), acc_list.std()), file=file)
        print("{:.2f}, {:.2f}".format(nmi_list.mean(), nmi_list.std()), file=file)
        print("{:.2f}, {:.2f}".format(ari_list.mean(), ari_list.std()), file=file)
        print("{:.2f}, {:.2f}".format(f1_list.mean(), f1_list.std()), file=file)
        file.close()
