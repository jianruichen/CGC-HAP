import torch

import utils
from layers import GraphConvolution
from opt import args
import torch.nn as nn
from typing import Any, Optional, Callable
import torch.nn.functional as F
import numpy as np
from torch_geometric.nn import GCNConv
from torch_geometric.nn import GATConv
from torch.nn.parameter import Parameter
import torch_geometric.data as geo_data
import torch_geometric.nn as geo_nn
import torch_geometric.utils as geo_utils
import copy
import torch
from torch_geometric.utils import subgraph

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv
import math

class AttentionLayer(nn.Module):
    def __init__(self, feature_dim, attention_dim):
            super(AttentionLayer, self).__init__()
            self.attention_weights = nn.Linear(feature_dim, attention_dim)
            self.context_vector = nn.Linear(attention_dim, 1, bias=False)

    def forward(self, x):
            # x shape: (batch_size, feature_dim)
            attention_scores = self.attention_weights(x)  # (batch_size, attention_dim)
            attention_scores = torch.tanh(attention_scores)
            attention_scores = self.context_vector(attention_scores)  # (batch_size, 1)
            attention_weights = torch.softmax(attention_scores, dim=1)
            return attention_weights

class encoding_network(nn.Module):
    def __init__(self, input_dim, hidden_dim, act, n_num, e_num,num_heads):
        super(encoding_network, self).__init__()

        self.AE1 = nn.Linear(input_dim, hidden_dim)
        self.AE2 = nn.Linear(input_dim, hidden_dim)

        self.GAT1 = GATConv(hidden_dim, hidden_dim, heads=num_heads)
        self.GAT2 = GATConv(hidden_dim, hidden_dim, heads=num_heads)

        # Initialize single-layer HGNN
        # self.hgnn1 = HypergraphNetwork(e_num, hidden_dim)
        # self.hgnn2 = HypergraphNetwork(e_num, hidden_dim)

        self.alpha1 = nn.Parameter(torch.Tensor(1, ))
        self.alpha1.data = torch.tensor(0.99999).to(args.device)
        self.alpha2 = nn.Parameter(torch.Tensor(1, ))
        self.alpha2.data = torch.tensor(0.99999).to(args.device)

        # self.beta = nn.Parameter(torch.Tensor(1, ))
        # self.beta.data = torch.tensor(0.99999).to(args.device)

        self.pos_weight = torch.ones(n_num * 2).to(args.device)
        self.pos_neg_weight = torch.ones([n_num * 2, n_num * 2]).to(args.device)
        self.pos_weight_h = torch.ones(n_num * 2).to(args.device)
        self.pos_neg_weight_h = torch.ones([n_num * 2, n_num * 2]).to(args.device)

        if act == "ident":
            self.activate = lambda x: x
        if act == "sigmoid":
            self.activate = nn.Sigmoid()

    def forward(self, x, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor):
        Z1 = self.activate(self.AE1(x))
        Z2 = self.activate(self.AE2(x))

        Z1 = F.normalize(Z1, dim=1, p=2)
        Z2 = F.normalize(Z2, dim=1, p=2)

        # 将邻接矩阵 A 转换为边索引和边权重
        edge_index, _ = geo_utils.dense_to_sparse(A)
        num_nodes = x.size(0)  # 获取节点的总数

        # 转换edge_index为Tensor（如果它还不是）
        edge_index_tensor = torch.tensor(edge_index, dtype=torch.long)

        # 检查是否有边的索引超出节点数的范围
        invalid_edges_mask = (edge_index_tensor >= num_nodes).any(dim=0)
        if invalid_edges_mask.any():
            print("存在无效的边。正在移除...")
            # 保留所有有效的边
            edge_index_tensor = edge_index_tensor[:, ~invalid_edges_mask]

        # 现在edge_index_tensor只包含有效的边
        # 如果你的图是无向的，确保每条边只记录一次
        # 因为无向图的边是双向的，在这里我们需要去除重复的边
        edge_index_sorted, _ = torch.sort(edge_index_tensor, dim=0)
        edge_index_unique = torch.unique(edge_index_sorted, dim=1)
        edge_index_max = edge_index.max()
        num_nodes = x.size(0)  # 假设X是你的节点特征矩阵
        if edge_index_max >= num_nodes:
            print(f"存在无效的索引: {edge_index_max.item()}, 节点总数: {num_nodes}")

        # 使用 GATConv 进行消息传递
        E1 = F.normalize(self.GAT1(Z1, edge_index_unique), dim=1, p=2)
        E2 = F.normalize(self.GAT2(Z2, edge_index_unique), dim=1, p=2)

        # 使用两个独立的超图神经网络编码器来处理高阶特征

        # ZH1 = self.hgnn1(Z1, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)
        # ZH2 = self.hgnn2(Z2, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)

        return Z1, Z2, E1, E2, _, _

class hypergraph_network(nn.Module):
    def __init__(self, input_dim, hidden_dim, act, n_num, e_num,num_heads):
        super(hypergraph_network, self).__init__()
        self.AE1 = nn.Linear(input_dim, hidden_dim)
        self.AE2 = nn.Linear(input_dim, hidden_dim)
        # Initialize single-layer HGNN
        self.hgnn1 = HypergraphNetwork(e_num, hidden_dim)
        self.hgnn2 = HypergraphNetwork(e_num, hidden_dim)

        if act == "ident":
            self.activate = lambda x: x
        if act == "sigmoid":
            self.activate = nn.Sigmoid()

    def forward(self, x, A, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor):

        Z1 = self.activate(self.AE1(x))
        Z2 = self.activate(self.AE2(x))

        Z1 = F.normalize(Z1, dim=1, p=2)
        Z2 = F.normalize(Z2, dim=1, p=2)

        ZH1 = self.hgnn1(Z1, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)
        ZH2 = self.hgnn2(Z2, H_tensor, D_v_inv_sqrt_tensor, D_e_inv_sqrt_tensor)

        return ZH1, ZH2




class Attention(nn.Module):
    def __init__(self, emb_dim, hidden_size=64):
        super(Attention, self).__init__()

        self.project = nn.Sequential(
            nn.Linear(emb_dim, hidden_size),
            #nn.Tanh(), # 激活
            nn.ReLU(),
            nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z):
        w = self.project(z) # n * 1 # [265 2 32]
        #print ('w')
        #print (w.shape)
        beta = torch.softmax(w, dim=1) # eq. 9
        return (beta * z).sum(1), beta

class Encoder(nn.Module):
    def __init__(self,
                 in_channels: int,
                 out_channels: int,
                 activation: Callable,
                 base_model: Any = None,
                 k: int = 2,
                 skip: bool = False):

        super(Encoder, self).__init__()
        self.base_model = base_model or GCNConv
        assert k >= 2
        self.k = k
        self.skip = skip

        if not self.skip:
            self.conv = nn.ModuleList([
                self.base_model(in_channels, 2 * out_channels)
            ])
            for _ in range(1, k - 1):
                self.conv.append(self.base_model(2 * out_channels, 2 * out_channels))
            self.conv.append(self.base_model(2 * out_channels, out_channels))
            self.activation = activation
        else:
            self.fc_skip = nn.Linear(in_channels, out_channels)
            self.conv = nn.ModuleList([
                self.base_model(in_channels, out_channels)
            ])
            for _ in range(1, k):
                self.conv.append(self.base_model(out_channels, out_channels))
            self.activation = activation

        self.weight = Parameter(torch.Tensor(out_channels, in_channels))
        self.reset_parameters()

    def reset_parameters(self):
        torch.nn.init.xavier_uniform_(self.weight)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        if not self.skip:
            for i in range(self.k):
                x = self.activation(self.conv[i](x, edge_index))
            return x
        else:
            h = self.activation(self.conv[0](x, edge_index))
            hs = [self.fc_skip(x), h]
            for i in range(1, self.k):
                u = sum(hs)
                hs.append(self.activation(self.conv[i](u, edge_index)))
            return hs[-1]

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GCN, self).__init__()
        # 在Python类中规定，函数的第一个参数是实例对象本身，并且约定俗成，把其名字写为self。
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nclass)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return F.log_softmax(x, dim=1)



class MLP(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        x = self.fc1(x)
        return x


class HypergraphConv(torch.nn.Module):
    def __init__(self, in_channels, out_channels):
        super(HypergraphConv, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        # Weight matrix Theta
        self.W = torch.nn.Parameter(torch.Tensor(self.in_channels, self.in_channels))
        torch.nn.init.kaiming_uniform_(self.W, a=np.sqrt(5))  # Parameter initialization
        self.theta = torch.nn.Parameter(torch.Tensor(out_channels, out_channels))
        torch.nn.init.kaiming_uniform_(self.theta, a=np.sqrt(5))  # Parameter initialization

    def forward(self, x, H, D_v_inv_sqrt, D_e_inv):
        # Apply D_e_inv to hyperedges
        H_de_normalized = torch.mm(D_e_inv, H.transpose(0, 1))

        # Propagate features through normalized hyperedges
        HW = torch.mm(self.W, H_de_normalized)

        # Transpose and propagate back to nodes
        HT_HW = torch.mm(H, HW)

        # Apply D_v_inv_sqrt to both sides
        Dv_HT_HW = torch.mm(D_v_inv_sqrt, HT_HW)
        output = torch.mm(Dv_HT_HW, D_v_inv_sqrt)

        # Apply input features x
        y = torch.mm(output, x)
        yf = torch.mm(y, self.theta)

        return yf

class HypergraphNetwork(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(HypergraphNetwork, self).__init__()
        self.conv1 = HypergraphConv(in_channels, out_channels)

    def forward(self, x, H, D_v_inv_sqrt, D_e_inv):
        x = torch.relu(self.conv1(x, H, D_v_inv_sqrt, D_e_inv))
        return x
class AttentionMLP(nn.Module):
    def __init__(self, input_dim, attention_dim, hidden_dims):
            super(AttentionMLP, self).__init__()
            self.attention_layer = AttentionLayer(input_dim, attention_dim)
            self.hidden_layers = nn.ModuleList([nn.Linear(input_dim, hidden_dims[0])])
            self.hidden_layers.extend(
                [nn.Linear(hidden_dims[i], hidden_dims[i + 1]) for i in range(len(hidden_dims) - 1)])
            self.output_layer = nn.Linear(hidden_dims[-1], 1)

    def forward(self, x):
            # Apply attention
            attention_weights = self.attention_layer(x)  # (batch_size, 1)
            weighted_x = x * attention_weights  # (batch_size, feature_dim)

            # Pass through hidden layers
            for hidden_layer in self.hidden_layers:
                weighted_x = F.relu(hidden_layer(weighted_x))

            # Output layer
            output = self.output_layer(weighted_x)
            return output

class CenterLoss(nn.Module):
    """定义中心损失"""
    def __init__(self, num_classes, feat_dim, device):
        super(CenterLoss, self).__init__()
        self.num_classes = num_classes
        self.feat_dim = feat_dim
        self.centers = nn.Parameter(torch.randn(num_classes, feat_dim))
        self.centers.to(device)

    def forward(self, features, labels):
        centers_batch = self.centers.index_select(0, labels)
        # loss = (features - centers_batch).pow(2).sum() / 2.0
        # loss = ((features - centers_batch).pow(2).sum(1)/features.shape[1]).mean()
        mae_loss = nn.L1Loss()
        loss = mae_loss(features, centers_batch)
        return loss