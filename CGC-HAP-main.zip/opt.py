import argparse

parser = argparse.ArgumentParser()

# dataset
parser.add_argument('--device', type=str, default="cuda", help='device.')
parser.add_argument('--dataset', type=str, default='cora', help='dataset name')
parser.add_argument('--cluster_num', type=int, default=3, help='cluster number')

# pre-process
parser.add_argument('--n_input', type=int, default=300, help='input feature dimension')
parser.add_argument('--t', type=int, default=1, help="filtering time of Laplacian filters")

# network
parser.add_argument('--beta', type=float, default=1, help='focusing factor beta')
parser.add_argument('--dims', type=int, default=[500], help='hidden unit')
parser.add_argument('--activate', type=str, default='ident', help='activate function')
parser.add_argument('--tao', type=float, default=0.9, help='high confidence rate')
parser.add_argument('--embeding_dims', type=int, default=500, help='hidden unit')
parser.add_argument('--dropout', type=float, default=0.1, help='hidden unit')
parser.add_argument('--eta_value', type=float, default=0.2, help='eta_value')


# parser.add_argument()

# training
parser.add_argument('--runs', type=int, default=10, help='runs')
parser.add_argument('--epochs', type=int, default=1000, help='training epoch')
parser.add_argument('--lr', type=float, default=1e-3, help='learning rate')
parser.add_argument('--seed', type=int, default=1, help='random seed')
parser.add_argument('--acc', type=float, default=0, help='acc')
parser.add_argument('--nmi', type=float, default=0, help='nmi')
parser.add_argument('--ari', type=float, default=0, help='ari')
parser.add_argument('--f1', type=float, default=0, help='f1')
parser.add_argument('--threshold', type=float, default=0.5, help='the threshold of high-confidence')

# community detection
parser.add_argument('--cd1', type=str, default='leiden')
# parser.add_argument('--cd2', type=str, default='leiden')
# parser.add_argument('--cd3', type=str, default='leiden')

# cav and ced
parser.add_argument('--cav1', type=float, default=0.1, help='community attribute voting')
parser.add_argument('--cav2', type=float, default=0.2, help='community attribute voting')
parser.add_argument('--ced', type=float, default=0.1, help='community edge dropping')
parser.add_argument('--ced_thr', type=float, default=1.)
parser.add_argument('--cav_thr', type=float, default=1.)


args = parser.parse_args()
